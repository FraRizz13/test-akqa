<?php

// Add Scripts
function cn_add_scripts(){
    // Add Main Css
    wp_enqueue_style('cn-main-style', plugins_url(). '/chucknorris/css/style.css');
    // add js file
    wp_enqueue_script('cn-main-script', plugins_url(). '/chucknorris/js/script.js');
}

add_action('wp_enqueue_scripts',  'cn_add_scripts');