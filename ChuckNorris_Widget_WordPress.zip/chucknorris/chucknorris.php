<?php
/*
Plugin Name: Chuck Norris Widget
Plugin URI: http://test-akqa.local/
Description: test chuck norris widget
Version: 1.0.0
Author: Frnacesco Rizzetto
Author URI: http://test-akqa.local/
*/

// Exit if accessed directly
if(!defined('ABSPATH')){
    exit;
}


//Load scripts
require_once(plugin_dir_path( __FILE__ ).'/includes/chucknorris-scripts.php');

//Load class
require_once(plugin_dir_path( __FILE__ ).'/includes/chucknorris-class.php');

// Registre widget
function register_chucknorris(){
    register_widget( 'ChuckNorris_Quotes_Widget' );
}

// Hook in function
add_action('widgets_init', 'register_chucknorris' );