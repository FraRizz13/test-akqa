**Component example**

This is an example module with components that may be useful 
for reference, testing, or for a quick demo. 

##Todo
- Add uninstall hook to remove all instances of blocks.
